# WorkBuddy 自动签到

![WorkBuddy Logo](https://download.codebuddy.cn/web/workbuddy/77c2617b394171f8938c8d4f0abce65e306fb458/assets/workbuddy-logo-WhgOvEF7.png)

支持安装了 Python 3.8 或更高版本的 Windows、macOS、Linux 电脑或服务器。脚本只使用 Python 标准库，不需要安装第三方包。

本项目先提供 WorkBuddy 多账号签到、状态和积分查询；后续会沿用同一配置和定时任务结构，逐步适配更多 Agent 的自动签到脚本。

## 1. 快速开始

把 `workbuddy_checkin.py` 放在一个目录中，打开终端进入该目录。

```bash
python workbuddy_checkin.py --setup
python workbuddy_checkin.py
```

如果系统没有 `python` 命令，Windows 改用 `py`，macOS/Linux 改用 `python3`。

`config.json` 初始是空数组。`--setup` 会读取当前设备上的 WorkBuddy 登录信息，并创建或更新该文件；再次导入同一 UID 只更新 token，不会产生重复账号。已有配置会先保存为 `config.json.bak`。

## 2. 自动获取 token

先在本机 WorkBuddy 客户端登录账号，再运行上面的 `--setup`。脚本会扫描登录信息文件 `workbuddy-desktop*.info`，按 UID 合并账号；多个历史账号可以一次导入，同一 UID 自动采用较新的文件。

常见目录：

- Windows：`%LOCALAPPDATA%\CodeBuddyExtension\Data\Public\auth`
- macOS：`~/Library/Application Support/CodeBuddyExtension/Data/Public/auth`
- Linux：`${XDG_DATA_HOME:-~/.local/share}/CodeBuddyExtension/Data/Public/auth`

Windows 可按 `Win+R` 打开上述目录；登录文件名通常是 `workbuddy-desktop.info`。

只想导入某个文件时：

```bash
python3 workbuddy_checkin.py --setup --auth-file "/path/to/workbuddy-desktop.info"
```

`--auth-file` 也可以填写包含这些 `.info` 文件的目录。

如果设备没有登录文件，请在交互终端运行 `--setup --manual`，然后按提示隐藏输入 token 并补充 UID。不要把 token 写在命令行参数中。

## 3. 服务器使用

服务器通常没有 WorkBuddy 客户端：

1. 在已登录的电脑运行 `--setup`。
2. 将 `workbuddy_checkin.py` 和生成的 `config.json` 通过安全方式复制到服务器。
3. 在服务器运行：

   ```bash
   python3 workbuddy_checkin.py --config /path/to/config.json
   ```

随后可使用系统计划任务或 `cron` 定时执行同一命令。

已有面板定时任务继续执行普通命令即可；更新后的 `config.json` 放回脚本同目录。

## 4. 青龙和其他定时任务

青龙面板新建“命令”任务，命令示例（按实际目录修改）：

```bash
python3 /ql/data/scripts/AICreditPunch/workbuddy_checkin.py --config /ql/data/scripts/AICreditPunch/config.json
```

可将定时设置为每天 `05:00`。Linux `cron` 示例：

```cron
0 5 * * * cd /opt/AICreditPunch && python3 workbuddy_checkin.py --config ./config.json >> workbuddy.log 2>&1
```

Windows 任务计划程序填写：程序 `python`（或 `py`），参数 `E:\\path\\AICreditPunch\\workbuddy_checkin.py --config E:\\path\\AICreditPunch\\config.json`，起始目录设为脚本目录。

## 5. config.json

文件可以是账号数组，也可以是包含 `accounts` 数组的对象。推荐使用数组：

```json
[
  {
    "enabled": true,
    "name": "账号1",
    "access_token": "ACCESS_TOKEN",
    "uid": "USER_UID",
    "domain": "www.workbuddy.cn",
    "enterprise_id": "",
    "api_base": "https://www.codebuddy.cn"
  }
]
```

- `enabled`：`false` 可暂时停用账号。
- `name`：仅用于区分日志。
- `access_token`：登录文件中的 `auth.accessToken`，只填 token 本身，不要加 `Bearer `。
- `uid`：登录文件中的 `account.uid`，用于识别和去重。
- `domain`：通常为 `www.workbuddy.cn`。
- `enterprise_id`：企业账号填写 `account.enterpriseId`，个人账号留空。
- `api_base`：通常保持 `https://www.codebuddy.cn`。

手动添加账号时，登录文件字段对应关系为：

```text
auth.accessToken     -> access_token
account.uid          -> uid
account.nickname     -> name
auth.domain          -> domain
account.enterpriseId -> enterprise_id
```

## 6. 常用命令

```text
--setup                    自动导入本机登录账号并更新 config.json
--manual                   与 --setup 同用，隐藏输入 token 手动配置
--auth-file PATH           指定登录信息文件
--config PATH              指定配置文件
--dry-run                  只检查配置，不发送请求
--status-only              只查询签到状态和积分，不领取
--debug                    输出脱敏后的响应，便于排查
--version                  查看版本
```

退出码为 `0` 表示所有启用账号处理成功；为 `1` 表示配置错误或至少一个账号失败。

## 7. 安全与更新

`config.json` 和 `config.json.bak` 都含登录凭据，只保存在自己的设备或服务器上，不要提交到公开仓库、截图或转发。重新登录 WorkBuddy 后，重新运行 `--setup` 更新 token；收到 `401` 或“凭证失效”时也按此操作。若 token 已泄露，请退出相关账号并重新登录。

## 8. 常见问题

- **找不到登录文件**：先打开 WorkBuddy 并完成登录；也可以使用 `--auth-file PATH` 指定实际文件。
- **手动配置**：没有桌面登录文件时，在交互终端运行 `python3 workbuddy_checkin.py --setup --manual`。
- **只导入一个账号**：确认历史登录文件仍在 auth 目录；不需要的账号可在 `config.json` 中设为 `enabled: false`。
- **JSON 配置错误**：检查双引号、逗号以及最外层的 `[`、`]`。
- **网络请求失败**：确认服务器可以访问 `https://www.codebuddy.cn`，稍后重试并用 `--debug` 查看脱敏信息。
